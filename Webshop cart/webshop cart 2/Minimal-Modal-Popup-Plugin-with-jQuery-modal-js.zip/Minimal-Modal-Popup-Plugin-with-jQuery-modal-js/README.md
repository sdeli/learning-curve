jquery.modal.js
===============

jquery.modal.js

options:
$('#exsample').modal();
$('#exsample1').modal({
      width:400,
			height:300,
			showSpeed: 2000,
			closeSpeed: 2000,
			autoClose:2000,
			overlay:true,
			shadow:true,
			autoOpen:true,
			title:false,
			action:'slide',
});
