


$(document).ready(openAndClose());
function openAndClose(){
	"use strict";

// Prepare-------------------------------------------------------------------------------------------------------------------------
	var transition=5;
	var transitionbtn=1;
	var transitionFast=2;
	var interval=transition*1000;
	var bookmarkContainerAll=$(".bookmark-container");
	var articleDiv=$("[data-openclose='in']");
	var articleDivInner=$(".inner");
	var buttonOpen=$(".bookmark-description button");
	var idCounter=0;
	// Create styles---------------------------------------------------------------------
		var styleopenclose=document.createElement("style");
		styleopenclose.id="openclose";
		styleopenclose.innerHTML=".classTransitionBtn{transition:all "+transitionbtn+"s 0s; border-radius: 0px !important; opacity:1;} .classTransition{transition:all "+transition+"s 0s} .classZero{min-height:0px; height:0px;} }";
		$("head")[0].appendChild(styleopenclose);

		// Add beginner Classes---------------------------------------------------------------
		articleDiv.addClass("classTransition");
		articleDiv.addClass("classZero");
	
	// calling functions------------------------------------------------------------------

		if(allgemeineObj.openAndCloseHandler===false){
		   for(var i=0; i<buttonOpen.length; i++){

				buttonOpen[i].addEventListener("click", function(){
					open(this);
					close(this);
					popUpCloseButton(this);
				});
		   }
			
			checkheightofInner();
			window.addEventListener("resize", checkheightofInner);
		}else{
			open(allgemeineObj.elem);
			popUpCloseButton(allgemeineObj.elem);
			allgemeineObj.openAndCloseHandler=false;
		}


// funktions Deaclaire-----------------------------------------------------------------------------------------------------------

	// checkheightofInner-------------------------------------------------------------------
		function checkheightofInner(){	
		    for(var i=0; i<articleDivInner.length; i++){

				if(articleDivInner[i].hasAttribute("data-index")===false){
				articleDivInner[i].setAttribute("data-index",i);
				}
					
				articleDivInner[i][1] =parseInt(window.getComputedStyle(articleDivInner[i], null).getPropertyValue("height"));
		    }
		}//checkheightofInner END----------------------------------------------------------------------------------

	// function open---------------------------------------------------------------------
		function open(buttonOpen){
			var elements=buttonOpen.parentElement.parentElement.children;
			var height="";
			var index="";
			var actualHeight="";
			for(var i=1; i<elements.length;i++){
				if(elements[i].hasAttribute("data-openclose")===true){
					index=parseInt(elements[i].children[0].getAttribute("data-index"));
					height=articleDivInner[index][1];
					actualHeight=parseInt(window.getComputedStyle(elements[i], null).getPropertyValue("height"));
				}
			}
			for(var i=0; i<elements.length; i++){
				if(elements[i].hasAttribute("data-openclose")===true && actualHeight<height && elements[i].hasAttribute("data-open")===false){

				 	elements[i].style.transition="all "+transition+"s 0s";
					elements[i].setAttribute("data-openclose","in");
					elements[i].setAttribute("data-open","in");
					var elem=elements[i];
					setTimeout(function(){elem.style.height=height+"px";},0);	
					setTimeout(function(){ if(elem.hasAttribute("data-close")===true){elem.removeAttribute("data-close");} }, 500);
					
					
				}		
			}
		}//open END----------------------------------------------------------------------------------

	// function close---------------------------------------------------------------------
		function close(buttonOpen){
			var elements=buttonOpen.parentElement.parentElement.children;
			var height="";
			var index="";
			var actualHeight="";
			for(var i=1; i<elements.length;i++){
				if(elements[i].hasAttribute("data-openclose")===true){
					index=parseInt(elements[i].children[0].getAttribute("data-index"));
					height=articleDivInner[index][1];
					actualHeight=parseInt(window.getComputedStyle(elements[i], null).getPropertyValue("height"));
				}
			}
			
			for(var i=0; i<elements.length; i++){
				if(elements[i].hasAttribute("data-openclose")===true  && actualHeight>0  && elements[i].hasAttribute("data-close")===false){
					
					elements[i].style.transition="all "+transitionFast+"s 0s";
					elements[i].setAttribute("data-openclose","out");
					elements[i].setAttribute("data-close","in");
					var elem=elements[i];
					setTimeout(function(){
					console.log(elem);
						elem.style.height="0px";},0);
					setTimeout(function(){ if(elem.hasAttribute("data-open")===true){elem.removeAttribute("data-open");} }, 0);

				}
			}
		}//close END----------------------------------------------------------------------------------

	// navigate togglebuttons-----------------------------------------------------------------------------------------------
	// ---------------------------------------------------------------------------------------------------------------------
	// ---------------------------------------------------------------------------------------------------------------------
		
		function popUpCloseButton(button){

				if(button.hasAttribute("data-clicked")===false){
				button.setAttribute("data-clicked","in")
				var element=$(button);
				var btnClose=0;
				var bullien=false;
				var hasBeenHidedOnce=false;
				var inAnimation=false;
				var inNer = animatedDiv(button);
				var idOfThis="popup-"+idCounter;
				var aTribute=checkIfOpenAnimatedDiv(button);
				var toggleButton=$("nav .navbar-toggle");
					
					updateCoordinates();
					checkIfreadyToPopCloseButton();
					window.addEventListener("resize", updateCoordinates);
					window.addEventListener("scroll", updateCoordinates);
					window.addEventListener("resize", checkIfreadyToPopCloseButton);
					window.addEventListener("scroll", checkIfreadyToPopCloseButton);
					window.addEventListener("resize", checkIfreadyToHideButton);
					window.addEventListener("scroll", checkIfreadyToHideButton);
					element[0].addEventListener("click",hideCloseButton);
					element[0].addEventListener("click",controllByByPositionTwoSec);
					window.addEventListener("resize", controllByByPositionbyScroll);
					window.addEventListener("scroll", controllByByPositionbyScroll);
				controllByByPositionTwoSec();
				}

				function updateCoordinates(){
					element[0][2]=element.offset().top;
					element[0][3]=element.offset().left;
					var elem=element[0].parentElement.parentElement.children;
					for(var i=0; i<elem.length; i++){
						if(elem[i].hasAttribute("data-openclose")===true){
							element[0][1]=parseInt(window.getComputedStyle(elem[i].children[0], null).getPropertyValue("height"));
						}
					}
		
				}//updateCoordinates()--------------------------------------------------------------------

				function checkIfreadyToPopCloseButton(){
					var inOrOut=checkIfOpenAnimatedDiv(button);
					var osszeg=element[0][1]+element[0][2];
					var query= $("#"+idOfThis).length;
					if(window.pageYOffset>element[0][2] && window.pageYOffset<osszeg && bullien===false && inAnimation===false && query<=0 && inOrOut==="in") {
	
							
						createCloseButton();
						inAnimation=true;
						bullien=true;
			
					}
				}//checkIfreadyToPopCloseButton()----------------------------------------------------------

				function checkIfreadyToHideButton(){
					var inOrOut=checkIfOpenAnimatedDiv(button);
					var query= $("#"+idOfThis).length;
					var osszeg=element[0][1]+element[0][2];
					if(window.pageYOffset<element[0][2] && bullien===true && inAnimation===false &&  query>0 && inOrOut==="in"){
						
						inAnimation=true;				
						hideCloseButton();
					}else if(window.pageYOffset>osszeg && bullien===true && inAnimation===false &&  query>0 ){
						
						inAnimation=true;				
						hideCloseButton();
					}


				}//checkIfreadyToHIDECloseButton()----------------------------------------------------------

				function createCloseButton(){
					console.log("breakja");
					btnClose=document.createElement("button");
					btnClose.classList.add("classTransitionBtn","btn","btn-danger","btn-block");
					btnClose.innerHTML="CLOSE THE ARTICLE";
					btnClose.id=idOfThis;
					idCounter=idCounter+1;
				
					
					flyUpCloseBtn();
					function flyUpCloseBtn(){

						$("body")[0].appendChild(btnClose);
						btnClose.style.position="absolute";
						btnClose.style.top=window.innerHeight+pageYOffset+"px";
						setTimeout(function(){ 
							$(btnClose)[0].addEventListener("click", function(){closeArticleOnClosebuttonClick(button,btnClose )});
							autoScroll($(element).parent().parent(),btnClose, false, false);
							btnClose.style.top="50px";
							btnClose.style.position="fixed";
							btnClose.style.opacity="0.7";
							inAnimation=false;

						}, 0);
						
						setTimeout(function(){
							var itterator=0;
							adjustPosOfBtnClose($(btnClose), itterator);
							$(window).on("resize", function(){adjustPosOfBtnClose($(btnClose), itterator)});
							toggleButton.on("click",function(){adjustPosOfBtnClose($(btnClose), itterator);});
						},1000);
						
						
					}

					function adjustPosOfBtnClose(btn, itterator){
						var loopItterator=0;
						setTimeout(function(){ loop(); },200) 

						function loop(){
							var top_=parseInt(btn.css("top"));
							var navBarHeight=parseInt($("nav").css("height"));
							console.log(navBarHeight);
							console.log(top_);
							if(top_!==navBarHeight){
								btn.css({"top":navBarHeight+"px"});
								console.log("bejott");
							}
						}// loop()
						itterator=itterator+1;
					}//adjustPosOfBtnClose(btn)
					
				}//createCloseButton() END-------------------------------------------------------------------

				function hideCloseButton(){
					
					if(btnClose!==0){
						btnClose.style.top=window.innerHeight+pageYOffset+200+"px";
							bullien=false;
							inAnimation=false;
							hasBeenHidedOnce=true;
							btnClose.style.opacity=0;
						setTimeout(function(){
							btnClose.parentElement.removeChild($("#"+idOfThis)[0]);
						}, 1000);
					}else {return;}
				}//hideCloseButton() END--------------------------------------------------------------------------	

				function closeArticleOnClosebuttonClick(elemForClose, triggerButton){
					var elem=elemForClose;
					triggerButton.style.opacity=0;
					hideCloseButton();
					close(elem);
						
					
				}//closeArticleOnClosebuttonClick END--------------------------------------------------------------------------	

				function controllByByPositionbyScroll(){
					var i=0;
					var inOrOut=checkIfOpenAnimatedDiv(button);
					var query= $("#"+idOfThis).length;
					var osszeg=element[0][1]+element[0][2];

					checkFast();
					function checkFast(){
						i++;
						
						if(pageYOffset>element[0][2] && pageYOffset<osszeg && inOrOut==="in" && i<3 && query<1){
							createCloseButton();
							inAnimation=true;
							bullien=true;
							setTimeout(function(){ checkFast(); }, 300);
						}
					}
				}//controllByByPosition END--------------------------------------------------------------------------	

				function controllByByPositionTwoSec(){
			
					var inOrOut=checkIfOpenAnimatedDiv(button);
					var query= $("#"+idOfThis).length;
					var osszeg=element[0][1]+element[0][2];
					
					if(pageYOffset>element[0][2] && pageYOffset<osszeg && inOrOut==="in" && query<1 && inOrOut==="in"){
						createCloseButton();
						inAnimation=true;
						bullien=true;

					}
					if(inOrOut==="in"){setTimeout(function(){ 
						controllByByPositionTwoSec(); }, 1500);}
					
				}//controllByByPosition END--------------------------------------------------------------------------	


				function animatedDiv(element){
					var elem=element.parentElement.parentElement.children;
					for(var i=0; i<elem.length; i++){
						if(elem[i].hasAttribute("data-openclose")===true){
							elem=elem[i].children[0];
							return(elem);
						}
					}
				}//animatedDiv() return element END--------------------------------------------------------------------------

				function checkIfOpenAnimatedDiv(element){
					var elem=element.parentElement.parentElement.children;
					for(var i=0; i<elem.length; i++){
						if(elem[i].hasAttribute("data-openclose")===true){
							elem=elem[i].getAttribute("data-openclose")
							return(elem);
						}
					}
				}//return data attribute value END--------------------------------------------------------------------------	

		}//popUpCloseButton(button) END--------------------------------------------------------------------------------

// END----------------------------------------------------------------------------------------------------------------------------------------
}
	



/*
inner heightjet 

arraybe beletolni az osszes heigtet az innereket domra es window resizre
classra ratenni es domra meg window resizra frissiteni

add button classt ratenni divre beanimalni kozepre btn-t 



*/