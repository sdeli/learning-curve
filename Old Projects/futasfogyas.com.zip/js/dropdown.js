var innerHtmlDropdown="<li id=\"dropdown-0\" class=\"classDropdown\" \"text-center\"><a >FUTÁS EDZÉSTERV KEZDŐKNEK ÉS HALADÓKNAK</a></li>";
	innerHtmlDropdown+="<li id=\"dropdown-1\" class=\"classDropdown\" \"text-center\"><a >ZSÍRÉGETÉS FUTÁSSAL <br> HATÉKONYAN</a></li>";
	innerHtmlDropdown+="<li id=\"dropdown-2\" class=\"classDropdown\" \"text-center\"><a >TEDD A TESTED ZSÍR OLVASZTÓ ERŐMŰVÉ</a></li>";
	innerHtmlDropdown+="<li id=\"dropdown-3\" class=\"classDropdown\" \"text-center\"><a >LEGJOBB KELLÉKEK AJÁNDÉKOK FUTÓKNAK</a></li>";
	innerHtmlDropdown+="<li id=\"dropdown-4\" class=\"classDropdown\" \"text-center\"><a >HOGYAN KEZDJÜNK EL FUTNI</a></li>";

           /* autoscroll carousel-IMG-4 --------------------------------------------------------------------- */

/*autoScroll($(element).parent().parent(),btnClose);*/
var whereToAppend=$("nav .dropDownNav a");
var whereToAppendSmall=$("nav .dropDownNav a");
var toggleButton=$("nav .navbar-toggle");
var navContainer=$("nav");
var navContainerCloseHeight=parseInt($(navContainer).css("height"))

$(document).ready(function(){// CALLING PROGRAMS----------------------------------------------------------------------------

		var go={//global object
		}

		if(window.innerWidth>768){
			go.eventhandling="big";
			dropDownBigScreen(whereToAppend, innerHtmlDropdown, 2 );
		}else{
			go.eventhandling="small";
			dropDownSmallScreen(whereToAppendSmall, innerHtmlDropdown, 2, toggleButton, go,navContainer,navContainerCloseHeight );
			
		}


	$(window).on("resize", function(){

		if(window.innerWidth>768 && go.eventhandling==="small"){
			go.eventhandling="big";
			dropDownBigScreen(whereToAppend, innerHtmlDropdown, 2 );

		}else if(window.innerWidth<=768 && go.eventhandling==="big"){
			go.eventhandling="small";
			dropDownSmallScreen(whereToAppendSmall, innerHtmlDropdown, 2, toggleButton, go,navContainer,navContainerCloseHeight );
		}
	});
});// CALLING PROGRAMS END----------------------------------------------------------------------------------------------


//DROPDOWN BIG SCREEN PROGRAM 1-----------------------------------------------------------------------------------------

function dropDownBigScreen(whereToAppend, innerHtmlDropdown, abstand ){
	 var gv={
	 	eventhandling:false
	 }


	// CALL FUNCTIONS----------------------------------------------------------------------------------------------------

	setTimeout(function(){
		createElements(gv, whereToAppend);//call functions function one--------------------------------------------------
		whereToAppend[0].addEventListener("click",callFunctions_two);
		window.addEventListener("resize", ceasedropDownBigScreen)
	},500);

	function callFunctions_two(){
	
		if(gv.eventhandling===false){
			dropDown(this, gv);
			eventhandling(gv);
			callAutoscroll();
		}else{
			pullUp(this, gv)
			eventhandling(gv);
		;}
	};// Call functions callFunctions_two END---------------------------------------------------------------------------

	function ceasedropDownBigScreen(){

		if(window.innerWidth<768 && $(gv.idReference).length>0){
		
			deleteOuterDiv(0);
			gv.eventhandling=false;

			whereToAppendSmall[0].removeEventListener("click", callFunctions_two);
			window.removeEventListener("click", ceasedropDownBigScreen);
		}
	}// Call functions callFunctions_three()----------------------------------------------------------------------------


	// CALL FUNCTIONS END-----------------------------------------------------------------------------------------------

	//SUB FUNCTIONS-----------------------------------------------------------------------------------------------------

		function eventhandling(elem){

			if(elem.eventhandling===false){
				elem.eventhandling=true;
			}else{elem.eventhandling=false}
			
		}//eventhandling(elem) END---------------------------------------------------------------------------------------

		function createElements(gv,elem){

				//create dropdown outer div -----------------------------------------------------------------------------
				gv.divOuter=createEl("div");
				gv.divOuter.id="divOuterdropDown";
				gv.idReference="#divOuterdropDown";
				gv.divOuter.title="big";
				gv.elemheight=parseInt($(elem).css("height"));
				$(gv.divOuter).css({"position":"absolute","overflow":"hidden", "height":"0px", "transition":"all 0.7s 0s", "top":gv.elemheight+"px"});
				$(elem).parent().append(gv.divOuter);
			
				//create dorpdowninnerdiv-------------------------------------------------------------------------------
				gv.divInner=createEl("div");
				gv.divInner.id="divInnerdropDown";
				gv.divInner.innerHTML=innerHtmlDropdown;
				$(gv.divInner).css({"position":"relative","background":"black","transition":"all 0.7s 0s"});
				$(gv.divOuter).append(gv.divInner);
				gv.height=parseInt($(gv.divInner).css("height"));
				$(gv.divInner)[0].style.top=-gv.height+"px";

				nightRider( $(gv.divInner).children() );

			}//createElements() END--------------------------------------------------------------------------------------

		function dropDown(elem, gv){
				$(gv.divOuter.parentElement).css({"position":"relative"});
				gv.divOuter.style.top=gv.elemheight+abstand+"px";
				gv.divOuter.style.height=gv.elemheight+gv.height+"px";

				setTimeout(function(){ 
						gv.divInner.style.top= abstand+"px";
				}, 10);

		}//dropDownON(elem) END------------------------------------------------------------------------------------------
	
		function pullUp(elem, gv){

				$(gv.divInner).css({"top":-gv.height+"px"});

				setTimeout(function(){ 
					gv.divOuter.style.top=gv.elemheight+"px";
					gv.divOuter.style.height="0px";
				}, 10);

		}// pullUp(elem, gv) END------------------------------------------------------------------------------------------

		function nightRider(elem){

			elem.each(function(index,value){
				$(value).on("mousenter",function(){highlight($(this))})
			})

			function highlight(elem){
				elem.css({"background":"white"});
			}
		}// Nightrider (elem, gv) END-------------------------------------------------------------------------------------

		function deleteOuterDiv(time){
			setTimeout(function(){ 
				$(gv.divOuter).remove();
				 	gv.divOuter="";
				 	gv.divInner="";
			}, time);

		}//dropDownSmallScreen pullUp(elem, gv) END-----------------------------------------------------------------------

	//HELPER FUNCTIONS----------------------------------------------------------------------------------------------------

		function createEl(elem,styles){

			var element=document.createElement(elem);
			return element;
		}

//DROPDOWN BIG SCREEN PROGRAM 1 Very END----------------------------------------------------------------------------------
} //END


//DROPDOWN SMALL SCREEN PROGRAM 2-------------------------------------------------------------------------------------------

	function dropDownSmallScreen(whereToAppendSmall, innerHtmlDropdown, abstand, toggleButton,go, navContainer, navContainerCloseHeight ){
	// EVENTHANDLER----------------------------------------------------------------------------------------------------------	
	 var gv={
	 	eventhandlingDropdown:false
	 }
	eventhandlingToggleBtn(0);
	// CALL FUNCTIONS---------------------------------------------------------------------------------------------------------
		toggleButton[0].addEventListener("click",callFunctions_one)
		whereToAppendSmall[0].addEventListener("click", callFunctions_two);
		window.addEventListener("resize", ceasedropDownSmallScreen);

		function callFunctions_one(){

			if(gv.eventhandlingToggleBtn===false){
				setTimeout(function(){createElements(gv, whereToAppendSmall);},200)
				eventhandlingToggleBtn(450);
			
			}else{

				eventhandlingToggleBtn(450);
				if(gv.divOuter){
					deleteOuterDiv(0);
				}
				if(gv.eventhandlingDropdown===true){
					eventhandlingDropdown(0);
				}
			}
			
		}// Call functions callFunctions_one()-----------------------------------------------------------------------

		function callFunctions_two(){
			if(gv.eventhandlingDropdown===false){
				dropDown(this, gv);
				eventhandlingDropdown(0);
				callAutoscroll();
			}else{
				pullUp(this, gv)
				eventhandlingDropdown(0);
				;}
		}// Call functions callFunctions_two()------------------------------------------------------------------------

		function ceasedropDownSmallScreen(){
			if(window.innerWidth>768){
				gv.eventhandlingDropdown=false;
				if($(gv.idReference).length>0){deleteOuterDiv(0);}
	  			window.removeEventListener("resize", ceasedropDownSmallScreen);
				toggleButton[0].removeEventListener("click",callFunctions_one)
				whereToAppendSmall[0].removeEventListener("click", callFunctions_two);
			}
		}// Call functions callFunctions_three()-----------------------------------------------------------------------

	// CALL FUNCTIONS END----------------------------------------------------------------------------------------------


	// HANDLE EVENTS---------------------------------------------------------------------------------------------------

		function eventhandlingDropdown(time){
			setTimeout(function(){ 
				if(gv.eventhandlingDropdown===false){
					gv.eventhandlingDropdown=true;
				}else{
					gv.eventhandlingDropdown=false;
					}
			
			}, time);
		}//HANDLE EVENTS dropDownSmallScreen eventhandlingDropdown(elem) END-------------------------------------------

		function eventhandlingToggleBtn(time){
			
			setTimeout(function(){
				var i=0
				var myVar = setInterval(function(){ 
					eventhandlingtogglebtn(); 
					i++; 
					if(i===5){clearInterval(myVar);}  
				}, 300);
			}, time);

			function eventhandlingtogglebtn(){
				if(parseInt($(navContainer).css("height"))<=navContainerCloseHeight){
					gv.eventhandlingToggleBtn=false;
					
				}else if(parseInt($(navContainer).css("height"))>navContainerCloseHeight){
					gv.eventhandlingToggleBtn=true;
				
				}

			}
		}//HANDLE EVENTS dropDownSmallScreen eventhandlingToggleBtn END-------------------------------------------------

	// HANDLE EVENTS END------------------------------------------------------------------------------------------------


		function createElements(gv,elem){
				//create dropdown outer div ----------------------------------------------------------------------------
				gv.divOuter=createEl("div");
				gv.divOuter.id="divOuterdropDown";
				gv.idReference="#divOuterdropDown";
				gv.divOuter.title="small";
				gv.elemheight=parseInt($(elem).css("height"));
				$(gv.divOuter).css({"position":"relative","overflow":"hidden", "height":"0px", "transition":"all 0.4s 0s", "top":0+"px"});
				$(elem).parent().append(gv.divOuter);
			
				//create dorpdowninnerdiv-------------------------------------------------------------------------------
				gv.divInner=createEl("div");
				gv.divInner.id="divInnerdropDown";
				gv.divInner.innerHTML=innerHtmlDropdown;
				$(gv.divInner).css({"position":"relative","background":"black","transition":"all 0.4s 0s"});
				$(gv.divOuter).append(gv.divInner);

				setTimeout(function(){
					
					$(gv.divInner).children().each(function(index, value){
						$(value).click(function() {
							pullUp(value, gv);
							eventhandlingDropdown(0);
						} );
					});
				}, 0);
				
				setTimeout(function(){ 
					gv.height=parseInt($(gv.divInner).css("height"));
					$(gv.divInner).css({"top":-gv.height+"px"});
					nightRider( $(gv.divInner).children() );
					
				}, 0);
			}//dropDownSmallScreen createElements() END-------------------------------------------------------	

		function dropDown(elem, gv){

			if(!gv.divOuter){
					createElements(gv, whereToAppendSmall);
				}

			setTimeout (function(){
				$(gv.divOuter).parent().css({"position":"relative"});
				gv.divOuter.style.top=0+"px";
				gv.divOuter.style.height=gv.height+"px";
			},0)

			setTimeout(function(){ 
					gv.divInner.style.top=0+"px";
			}, 10);

		}//dropDownSmallScreen dropDown(elem) END--------------------------------------------------------------------------------

		function pullUp(elem, gv){

				$(gv.divInner).css({"top":-gv.height+"px"});

				setTimeout(function(){ 
					gv.divOuter.style.top=gv.elemheight+"px";
					gv.divOuter.style.height="0px";
				}, 10);

		}//dropDownSmallScreen pullUp(elem, gv) END-----------------------------------------------------------

		function deleteOuterDiv(time){
			setTimeout(function(){ 
				$(gv.divOuter).remove();
				 	gv.divOuter="";
				 	gv.divInner="";
			
			}, time);

		}//dropDownSmallScreen pullUp(elem, gv) END------------------------------------------------------------
		function nightRider(elem){

			elem.each(function(index,value){
				$(value).on("mousenter",function(){highlight($(this))})
			})

			function highlight(elem){
				elem.css({"background":"white"});
			}
		}//dropDownSmallScreen Nightrider (elem, gv) END---------------------------------------------------------

	//HELPER FUNCTIONS-------------------------------------------------------------------------------------------

		function createEl(elem,styles){

			var element=document.createElement(elem);
			return element;
		}

//DROPDOWN BIG SCREEN PROGRAM 1 Very END-------------------------------------------------------------------------
}//END




function callAutoscroll(){	

 			var img=$("#dropdown-0")[0];
          var article=$("#bookmark-container-0")
          autoScroll(article, img,true, true);

           /* autoscroll carousel-IMG-4 --------------------------------------------------------------------- */

           var img1=$("#dropdown-1")[0];
          var article1=$("#bookmark-container-1")
          autoScroll(article1, img1,true, true);

           /* autoscroll carousel-IMG-4 --------------------------------------------------------------------- */

           var img2=$("#dropdown-2")[0];
          var article2=$("#bookmark-container-7")
          autoScroll(article2, img2,true, true);

           /* autoscroll carousel-IMG-4 --------------------------------------------------------------------- */

           var img3=$("#dropdown-3")[0];
          var article3=$("#bookmark-container-2")
          autoScroll(article3, img3,true, true);

           /* autoscroll carousel-IMG-4 --------------------------------------------------------------------- */

            var img4=$("#dropdown-4")[0];
          var article4=$("#bookmark-container-3")
          autoScroll(article4, img4,true, true);

           /* autoscroll carousel-IMG-4 --------------------------------------------------------------------- */
}
