		
		$(document).ready(function(){logoSwitch();})



		function logoSwitch(){//--------------------------------------------------------------------

		setLogo();
		window.addEventListener("resize",switchToBigLogo);
		window.addEventListener("resize",switchToThumbNailLogo);

		function switchToBigLogo(){
			if(window.innerWidth>=1000 && $("#logo-img")[0] && $("#logo-img")[0].hasAttribute("data-biglogo")===false){

				var logoDiv=$(".navbar-brand")[0]
				logoDiv.removeChild(logoDiv.children[0])

				var logoImg=document.createElement("img");
				logoImg.id="logo-img";
				logoImg.src="img/logo-running-big-b.png";
				logoImg.setAttribute("data-biglogo","in");
				logoDiv.appendChild(logoImg);
			}
		}// setLogo()End--------------------------------------------------------------------

		function switchToThumbNailLogo(){
			if(window.innerWidth<1000 && $("#logo-img")[0] && $("#logo-img")[0].hasAttribute("data-thumblogo")===false){

				var logoDiv=$(".navbar-brand")[0]
				logoDiv.removeChild(logoDiv.children[0])

				var logoImg=document.createElement("img");
				logoImg.id="logo-img";
				logoImg.src="img/logo-running-small.png";
				logoImg.setAttribute("data-thumblogo","in");
				logoDiv.appendChild(logoImg);
				logoImg.style.marginLeft="15px";
			}
		}// setLogo()End--------------------------------------------------------------------


		function setLogo(){

			var logoDiv=$(".navbar-brand")[0];
			var logoImg=document.createElement("img");
			logoImg.id="logo-img";

			if(window.innerWidth>1000){
			logoImg.src="img/logo-running-big-b.png";
			}else{
				logoImg.src="img/logo-running-small.png";
				logoImg.style.marginLeft="15px";
			}

			logoDiv.appendChild(logoImg);
		}// setLogo()End--------------------------------------------------------------------
		 callAutoscrollOnLogo();
		 
        function callAutoscrollOnLogo(){
          var img10=$(".navbar-brand img")[0];
          var article10=$("body");
          autoScroll(article10, img10, false, false);
        }
		
// END Logo switchEnd----------------------------------------------------------------------------------------------------------
}