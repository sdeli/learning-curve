
function autoScroll(article,img,openAndCloseHandler, startOpenAndClose){

	if(img.getAttribute("id").indexOf("dropdown")<=-1){
	var caption=caption(img);
	addEventListenerToCaption(caption);
	}

	img.addEventListener("click", function(){autoScrollToTarget()});

	
	function checkOffsetHeight(articleDiv){
		
		var articleOffset=articleDiv;
		var offsetHeight=article.offset().top;
		if(article.parentElement){
			articleOffset=article.parentElement;
			offsetHeight=offsetHeight+articleOffset.offset.top;
			checkOffsetHeight(article);
		}else {return offsetHeight;}
	}

	function autoScrollToTarget(){
			
			if(article.selector!=="body"){
			var targetOffsetTop=checkOffsetHeight(article)-80;

			}else{var targetOffsetTop=60;}

			var theCSSprop = parseInt(window.getComputedStyle($("body")[0], null).getPropertyValue("height"));

			if( window.pageYOffset<=(targetOffsetTop-40) || window.pageYOffset>=(targetOffsetTop+40)){

				var errEignis=window.pageYOffset-targetOffsetTop;

				if(errEignis>0 && errEignis>20){
					
					window.scrollTo(0, window.pageYOffset-40);
					setTimeout(function(){ autoScrollToTarget(); }, 10);
				}else if(errEignis<0 && errEignis<-20 ){

					if(window.pageYOffset<(theCSSprop-window.innerHeight)){
						console.log("majom")
						allgemeineObj.openAndCloseHandler=openAndCloseHandler;
						allgemeineObj.elem=$(article.selector+" "+".bookmark-description button")[0];
					 if(startOpenAndClose===true){openAndClose();}	
					}
						
					window.scrollTo(0, window.pageYOffset+40);
					setTimeout(function(){ autoScrollToTarget(); }, 5);
					
					
				}else {

					setTimeout(function(){ autoScrollToTarget(); }, 3000);}
				
			}else{
		
				allgemeineObj.openAndCloseHandler=openAndCloseHandler;
				allgemeineObj.elem=$(article.selector+" "+".bookmark-description button")[0];
				if(startOpenAndClose===true){openAndClose();}
				}	

	}


	function caption(elem){

		for(var element=elem.parentElement.children, i=0; i<element.length; i++){
			

			if(element[i].getAttribute("class")==="carousel-caption"){
				return element[i];
			}
		} return false;
	}

	function addEventListenerToCaption(elem){
		if(elem!==false){
			caption.addEventListener("click", function(){autoScrollToTarget()});
		}else {return;}
	}
}



$(document).ready(function(){callAutoscroll_2();});

function callAutoscroll_2(){
         /* autoscroll carousel-IMG-0 --------------------------------------------------------------------- */
          var img1=$("#carousel-img-0")[0];
          var article1=$("#bookmark-container-0");
          autoScroll(article1, img1, true, true, true);

         /* autoscroll carousel-IMG-1 --------------------------------------------------------------------- */

          var img2=$("#carousel-img-1")[0];
          var article2=$("#bookmark-container-1");
          autoScroll(article2, img2, true, true, true);

          /* autoscroll carousel-IMG-2 --------------------------------------------------------------------- */

          var img3=$("#carousel-img-2")[0];
          var article3=$("#bookmark-container-7");
          autoScroll(article3, img3, true, true, true);

          /* autoscroll carousel-IMG-3 --------------------------------------------------------------------- */

          var img4=$("#carousel-img-3")[0];
          var article4=$("#bookmark-container-2");
          autoScroll(article4, img4, true, true, true);

          /* autoscroll carousel-IMG-4 --------------------------------------------------------------------- */

          var img5=$("#carousel-img-4")[0];
          var article5=$("#bookmark-container-3");
          autoScroll(article5, img5, true, true, true);

           /* autoscroll carousel-IMG-4 --------------------------------------------------------------------- */

          var img6=$("#programozd-1")[0];
          var article6=$("#bookmark-container-7");
          autoScroll(article6, img6, true, true, true);

           /* autoscroll carousel-IMG-4 --------------------------------------------------------------------- */

          var img6=$("#programozd-2")[0];
          var article6=$("#bookmark-container-7");
          autoScroll(article6, img6, true, true, true	);

           /* autoscroll carousel-IMG-4 --------------------------------------------------------------------- */

          var img7=$("#programozd-3")[0];
          var article7=$("#bookmark-container-7");
          autoScroll(article7, img7, true, true, true);

           /* autoscroll carousel-IMG-4 --------------------------------------------------------------------- */

          var img8=$("#programozd-4")[0];
          var article8=$("#bookmark-container-7");
          autoScroll(article8, img8, true, true, true);

           /* autoscroll carousel-IMG-4 --------------------------------------------------------------------- */

          var img9=$("#programozd-5")[0];
          var article9=$("#bookmark-container-7");
          autoScroll(article9, img9, true, true, true);

           /* autoscroll carousel-IMG-4 --------------------------------------------------------------------- */
}
