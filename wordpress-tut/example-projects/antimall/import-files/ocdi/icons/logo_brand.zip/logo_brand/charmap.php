<?php $icons = array();
$icons['logo_brand']['logo-retro'] = array("class"=>'logo-retro',"tags"=>'logo-1',"unicode"=>'');
$icons['logo_brand']['logo-2-01'] = array("class"=>'logo-2-01',"tags"=>'logo-2-01',"unicode"=>'');
$icons['logo_brand']['logo-3'] = array("class"=>'logo-3',"tags"=>'logo-3',"unicode"=>'');
$icons['logo_brand']['logo-4-01'] = array("class"=>'logo-4-01',"tags"=>'logo-4-01',"unicode"=>'');
$icons['logo_brand']['logo-5-01'] = array("class"=>'logo-5-01',"tags"=>'logo-5-01',"unicode"=>'');
$icons['logo_brand']['logo-6-01'] = array("class"=>'logo-6-01',"tags"=>'logo-6-01',"unicode"=>'');