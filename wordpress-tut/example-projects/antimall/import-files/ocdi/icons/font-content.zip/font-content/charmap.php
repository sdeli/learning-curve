<?php $icons = array();
$icons['font-content']['cart'] = array("class"=>'cart',"tags"=>'cart',"unicode"=>'');
$icons['font-content']['contract'] = array("class"=>'contract',"tags"=>'contract',"unicode"=>'');
$icons['font-content']['money-bag'] = array("class"=>'money-bag',"tags"=>'money-bag',"unicode"=>'');
$icons['font-content']['new-product'] = array("class"=>'new-product',"tags"=>'new-product',"unicode"=>'');