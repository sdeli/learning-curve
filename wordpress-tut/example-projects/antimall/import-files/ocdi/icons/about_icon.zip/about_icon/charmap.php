<?php $icons = array();
$icons['about_icon']['give-money'] = array("class"=>'give-money',"tags"=>'give-money',"unicode"=>'');
$icons['about_icon']['paint-palette-and-brush'] = array("class"=>'paint-palette-and-brush',"tags"=>'paint-palette-and-brush',"unicode"=>'');
$icons['about_icon']['settings'] = array("class"=>'settings',"tags"=>'settings',"unicode"=>'');
$icons['about_icon']['smiling-girl'] = array("class"=>'smiling-girl',"tags"=>'smiling-girl',"unicode"=>'');