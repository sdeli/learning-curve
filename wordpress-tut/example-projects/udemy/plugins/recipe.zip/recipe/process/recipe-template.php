<ul class="list-unstyled">
    <li>
        <strong>RATE_I18N: </strong>
        <div id="recipe_rating" class="rateit"
            READONLY_PLACEHOLDER data-rateit-value="RECIPE_RATING"
            data-rateit-resetable="false" data-rid="RECIPE_ID"></div>
    </li>
    <li><strong>ORIGIN_I18N: </strong> ORIGIN_PH MORE_INFO_URL_PH</li>
</ul>