<div id="recipe-status"></div>
<form id="recipe-form">
  <div class="form-group">
    <label>Title</label>
    <input type="text" class="form-control" id="r_inputTitle">
  </div>
  CONTENT_EDITOR
  <hr>
  <div class="form-group">
    <label>Featured Image <a href="#" id="recipe-img-upload-btn">Upload</a></label>
    <br>
    <img id="recipe-img-preview">
    <input type="hidden" id="r_inputImgID">
  </div>
  <div class="form-group">
    <button type="submit" class="btn btn-primary">Submit Recipe</button>
  </div>
</form>