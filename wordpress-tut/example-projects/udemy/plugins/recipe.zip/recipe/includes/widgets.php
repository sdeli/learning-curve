<?php

function r_widgets_init(){
  register_widget( 'R_Daily_Recipe_Widget' );
}